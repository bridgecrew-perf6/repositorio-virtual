<?php
$rol = $_SESSION['id_rol'];
$user = $_SESSION['loggedUserName'];
?>

<!-- Estilos de CSS -->
<link rel="stylesheet" href="public/css/style_pcnt.css">

<!-- contenedor -->
<div class="content">
    <h3>Página Autor</h3>

</div>

<!-- Gitter Chat Link -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.1/js/materialize.min.js"></script>
<script type = "text/javascript" src = "https://code.jquery.com/jquery-2.1.1.min.js"></script>           
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
