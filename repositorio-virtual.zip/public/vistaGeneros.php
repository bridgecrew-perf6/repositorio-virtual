<!-- Estilos en CSS -->

<?php

?>
<!DOCTYPE html>
<html lang="es">
    <h2> aqui se mostrará todos los libros con la categoría Especificada</h2>

</html>


